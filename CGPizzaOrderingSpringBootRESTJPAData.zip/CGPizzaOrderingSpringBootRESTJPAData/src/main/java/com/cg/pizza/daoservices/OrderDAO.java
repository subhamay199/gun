package com.cg.pizza.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.pizza.beans.Order;

public interface OrderDAO extends JpaRepository<Order, Integer>{

}
