package com.cg.pizza.services;

import java.util.List;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Order;
import com.cg.pizza.exception.CustomerDetailsNotFound;
import com.cg.pizza.exception.OrderDetailsNotFound;

	public interface PizzaOrderingServices {
		Customer acceptCustomerDetails(Customer customer);
		Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFound;
		List<Customer> getAllCustomerDetails();
		Order acceptOrderDetails(Order order);
		Order getOrderIdDetails(int orderId) throws OrderDetailsNotFound;
		List<Order> getAllOrderDetails();
		boolean removeOrderDetails(int orderId)throws OrderDetailsNotFound;

		

}


