package com.cg.pizza.response;

public class PizzaResponse {
	private String errorMessage;
	private int StatusCode;
	public PizzaResponse(String errorMessage, int statusCode) {
		super();
		this.errorMessage = errorMessage;
		StatusCode = statusCode;
	}
	
	public PizzaResponse() {}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public int getStatusCode() {
		return StatusCode;
	}

	public void setStatusCode(int statusCode) {
		StatusCode = statusCode;
	}

	@Override
	public String toString() {
		return "CustomeResponse [errorMessage=" + errorMessage + ", StatusCode=" + StatusCode + "]";
	}
}
