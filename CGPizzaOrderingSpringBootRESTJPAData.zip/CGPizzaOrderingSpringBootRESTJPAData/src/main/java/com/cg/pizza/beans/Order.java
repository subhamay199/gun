package com.cg.pizza.beans;

import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	private int orderQuantity;
	private int orderPrice;
	private String pizzaType;
	private String pizzaSize;

	
	@ManyToOne
	private Customer customer;
	
	public Order() {}

	public Order(int orderId, int orderQuantity, int orderPrice, String pizzaType, String pizzaSize,
			Customer customer) {
		super();
		this.orderId = orderId;
		this.orderQuantity = orderQuantity;
		this.orderPrice = orderPrice;
		this.pizzaType = pizzaType;
		this.pizzaSize = pizzaSize;
		this.customer = customer;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public int getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}

	public String getPizzaType() {
		return pizzaType;
	}

	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}

	public String getPizzaSize() {
		return pizzaSize;
	}

	public void setPizzaSize(String pizzaSize) {
		this.pizzaSize = pizzaSize;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderQuantity=" + orderQuantity + ", orderPrice=" + orderPrice
				+ ", pizzaType=" + pizzaType + ", pizzaSize=" + pizzaSize + ", customer=" + customer + "]";
	}
	
}	