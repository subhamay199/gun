package com.cg.pizza.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Order;
import com.cg.pizza.exception.CustomerDetailsNotFound;
import com.cg.pizza.exception.OrderDetailsNotFound;
import com.cg.pizza.services.PizzaOrderingServices;


@Controller
public class pizzaServicesController {
@Autowired
	PizzaOrderingServices pizzaServices;
@RequestMapping(value={"/sayHello"},method=RequestMethod.GET)
public ResponseEntity<String> sayHello(){
	return new ResponseEntity<String>("Hello",HttpStatus.OK);
}
@RequestMapping(value={"/getCustomerDetails/{customerId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<Customer> getCustomerDetailsPathParam(@PathVariable(value="customerId")int customerId) throws CustomerDetailsNotFound{
	Customer customer=pizzaServices.getCustomerDetails(customerId);
	return new ResponseEntity<Customer>(customer,HttpStatus.OK);
}
@RequestMapping(value={"/getAllCustomerDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<List<Customer>> geCustomerDetailsPathParam() {
		return new ResponseEntity<List<Customer>>(pizzaServices.getAllCustomerDetails(),HttpStatus.OK);
}
@RequestMapping(value={"/acceptCustomerDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptCustomerDetails(@ModelAttribute Customer customer) throws CustomerDetailsNotFound{
	customer=pizzaServices.acceptCustomerDetails(customer);
	return new ResponseEntity<>("customer details successfully added customerId"+customer.getCustomerId(),HttpStatus.OK);
	}	

@RequestMapping(value={"/acceptOrderDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptOrderDetails(@ModelAttribute Order order) throws OrderDetailsNotFound{
	order=pizzaServices.acceptOrderDetails(order);
	return new ResponseEntity<>("order details successfully added orderId"+order.getOrderId(),HttpStatus.OK);
	}	


@RequestMapping(value={"/getOrderDetails/{orderId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<Order> getOrderDetailsPathParam(@PathVariable(value="orderId")int orderId) throws OrderDetailsNotFound{
	Order order=pizzaServices.getOrderIdDetails(orderId);
	return new ResponseEntity<Order>(order,HttpStatus.OK);
	
}
@RequestMapping(value={"/getAllOrderDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<List<Order>> geOderDetailsPathParam() {
		return new ResponseEntity<List<Order>>(pizzaServices.getAllOrderDetails(),HttpStatus.OK);
}
@RequestMapping(value={"/removeOrderDetails"},method=RequestMethod.DELETE,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE
)
public ResponseEntity<String> removeOrderDetailsRequestParam(@RequestParam int orderId) throws OrderDetailsNotFound{
	
	
	pizzaServices.removeOrderDetails(orderId);
	return new ResponseEntity<>("order details successfully removed",HttpStatus.OK);
}
}