package com.cg.pizza.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Order;
import com.cg.pizza.daoservices.CustomerDAO;
import com.cg.pizza.daoservices.OrderDAO;
import com.cg.pizza.exception.CustomerDetailsNotFound;
import com.cg.pizza.exception.OrderDetailsNotFound;



@Component("pizzaOrderingServices")
public class PizzaOrderingServicesImpl implements PizzaOrderingServices{
	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private OrderDAO orderDAO;
	
	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		customer=customerDAO.save(customer);
		return customer;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFound {
		return customerDAO.findById(customerId).orElseThrow(()->new CustomerDetailsNotFound("customer details not found for the customerId"+customerId));
		 
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDAO.findAll();
	}

	

	@Override
	public Order getOrderIdDetails(int orderId) throws OrderDetailsNotFound {
		return orderDAO.findById(orderId).orElseThrow(()->new OrderDetailsNotFound("order details not found for the oderId"+orderId));
	}

	@Override
	public List<Order> getAllOrderDetails() {
		return orderDAO.findAll();
	}

	@Override
	public boolean removeOrderDetails(int orderId) throws OrderDetailsNotFound {
		orderDAO.deleteById(orderId);
		return true;
	}

	@Override
	public Order acceptOrderDetails(Order order) {
		order=orderDAO.save(order);
		return order;
	}

	


	}


