package com.cg.movie.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Music;

public interface MusicDAO extends JpaRepository<Music, Integer>{

}
