package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.daoservices.MusicDAO;
import com.cg.movie.exceptions.MovieDetailsNotFound;


@Component("movieServices")
public class MovieServicesImpl implements MovieServices{
	@Autowired
	private MovieDAO movieDAO;
	@Autowired
	private MusicDAO musicDAO;
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		movie=movieDAO.save(movie);
		return movie;
	}

	@Override
	public Movie getMovieDetails(int movieId) throws MovieDetailsNotFound {
		return movieDAO.findById(movieId).orElseThrow(()->new MovieDetailsNotFound("movie details not found for the movie ID"+movieId));
		 
	}

	@Override
	public List<Movie> getAllMovieDetails() {
		return movieDAO.findAll();
	}

	@Override
	public boolean removeMovieDetails(int movieId) throws MovieDetailsNotFound {
		movieDAO.deleteById(movieId);
		return true;
	}

}
