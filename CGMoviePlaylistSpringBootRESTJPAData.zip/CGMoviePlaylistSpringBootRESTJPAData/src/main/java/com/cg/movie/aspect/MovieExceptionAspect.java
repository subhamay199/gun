package com.cg.movie.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;


import com.cg.movie.exceptions.MovieDetailsNotFound;
import com.cg.movie.response.MovieResponse;


@ControllerAdvice
public class MovieExceptionAspect {
	
	@ExceptionHandler(MovieDetailsNotFound.class)
	public ResponseEntity<MovieResponse>handleAssociateDetailsNotFoundException(Exception e) {
		MovieResponse response=new MovieResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	
	

}
