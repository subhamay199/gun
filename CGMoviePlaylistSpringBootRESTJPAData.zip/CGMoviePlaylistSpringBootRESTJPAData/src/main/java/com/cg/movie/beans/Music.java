package com.cg.movie.beans;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Music {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int musicId;
private String songName;
private String songGenre;
@ManyToOne
private Movie movie;
public Music() {}
public Music(String songName, String songGenre) {
	super();
	this.songName = songName;
	this.songGenre = songGenre;
}
public Music(int musicId, String songName, String songGenre) {
	super();
	this.musicId = musicId;
	this.songName = songName;
	this.songGenre = songGenre;
	
}
public int getMusicId() {
	return musicId;
}
public void setMusicId(int musicId) {
	this.musicId = musicId;
}
public String getSongName() {
	return songName;
}
public void setSongName(String songName) {
	this.songName = songName;
}
public String getSongGenre() {
	return songGenre;
}
public void setSongGenre(String songGenre) {
	this.songGenre = songGenre;
}
public Movie getMovie() {
	return movie;
}
public void setMovie(Movie movie) {
	this.movie = movie;
}
@Override
public String toString() {
	return "Music [musicId=" + musicId + ", songName=" + songName + ", songGenre=" + songGenre +  "]";
}

}
