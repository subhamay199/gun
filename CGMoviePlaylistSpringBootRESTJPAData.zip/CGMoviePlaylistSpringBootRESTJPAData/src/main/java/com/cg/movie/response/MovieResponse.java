package com.cg.movie.response;

public class MovieResponse {
	private String errorMessage;
	private int StatusCode;
	public MovieResponse(String errorMessage, int statusCode) {
		super();
		this.errorMessage = errorMessage;
		StatusCode = statusCode;
	}
	
	public MovieResponse() {}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public int getStatusCode() {
		return StatusCode;
	}

	public void setStatusCode(int statusCode) {
		StatusCode = statusCode;
	}

	@Override
	public String toString() {
		return "CustomeResponse [errorMessage=" + errorMessage + ", StatusCode=" + StatusCode + "]";
	}
}
