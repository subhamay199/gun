package com.cg.employee.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	
	private int pinCode;
	private String state;
	private String city;
	
	public Address() {}

	public Address(int pinCode, String state, String city) {
		super();
		this.pinCode = pinCode;
		this.state = state;
		this.city = city;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [pinCode=" + pinCode + ", state=" + state + ", city=" + city + "]";
	}

	
	

}
