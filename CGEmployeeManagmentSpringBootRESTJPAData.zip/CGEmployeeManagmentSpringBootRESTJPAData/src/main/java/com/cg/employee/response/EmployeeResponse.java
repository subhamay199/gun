package com.cg.employee.response;

public class EmployeeResponse {
	private String errorMessage;
	private int StatusCode;
	public EmployeeResponse(String errorMessage, int statusCode) {
		super();
		this.errorMessage = errorMessage;
		StatusCode = statusCode;
	}
	
	public EmployeeResponse() {}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public int getStatusCode() {
		return StatusCode;
	}

	public void setStatusCode(int statusCode) {
		StatusCode = statusCode;
	}

	@Override
	public String toString() {
		return "CustomeResponse [errorMessage=" + errorMessage + ", StatusCode=" + StatusCode + "]";
	}
}
