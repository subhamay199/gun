package com.cg.employee.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.employee.beans.Employee;
import com.cg.employee.exception.EmployeeNotFound;
import com.cg.employee.services.EmployeeServices;


@Controller
public class employeeServicesController {
@Autowired
	EmployeeServices employeeServices;
@RequestMapping(value={"/sayHello"},method=RequestMethod.GET)
public ResponseEntity<String> sayHello(){
	return new ResponseEntity<String>("Hello",HttpStatus.OK);
}
@RequestMapping(value={"/getEmployeeDetails/{employeeId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<Employee> getEmployeeDetailsPathParam(@PathVariable(value="employeeId")int employeeId) throws EmployeeNotFound{
	Employee employee=employeeServices.getEmployeeDetails(employeeId);
	return new ResponseEntity<Employee>(employee,HttpStatus.OK);
}
@RequestMapping(value={"/getAllEmployeeDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<List<Employee>> getAssociateDetailsPathParam() {
		return new ResponseEntity<List<Employee>>(employeeServices.getAllEmployeeDetails(),HttpStatus.OK);
}
@RequestMapping(value={"/acceptEmployeeDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptEmployeeDetails(@ModelAttribute Employee employee) throws EmployeeNotFound{
	employee=employeeServices.acceptEmployeeDetails(employee);
	return new ResponseEntity<>("Employee details successfully added employeeId"+employee.getEmployeeId(),HttpStatus.OK);
}
@RequestMapping(value={"/removeEmployeeDetails"},method=RequestMethod.DELETE,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE
)
public ResponseEntity<String> removeMovieDetailsRequestParam(@RequestParam int employeeId) throws EmployeeNotFound{
	
	
	employeeServices.removeEmployeeDetails(employeeId);
	return new ResponseEntity<>("Employee details successfully removed",HttpStatus.OK);
}
}