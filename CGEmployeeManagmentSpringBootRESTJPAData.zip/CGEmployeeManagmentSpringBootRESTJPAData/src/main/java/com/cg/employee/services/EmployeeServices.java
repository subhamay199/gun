package com.cg.employee.services;

import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.exception.EmployeeNotFound;

	public interface EmployeeServices {
		Employee acceptEmployeeDetails(Employee employee);
		Employee getEmployeeDetails(int employeeId) throws EmployeeNotFound;
		List<Employee> getAllEmployeeDetails();
		boolean removeEmployeeDetails(int employeeId)throws EmployeeNotFound;
}


