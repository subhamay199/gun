package com.cg.employee.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employee.beans.Employee;
import com.cg.employee.daoservices.EmployeeDAO;

import com.cg.employee.exception.EmployeeNotFound;



@Component("EmployeeServices")
public class EmployeeServicesImpl implements EmployeeServices{
	@Autowired
	private EmployeeDAO employeeDAO;
	
	@Override
	public Employee acceptEmployeeDetails(Employee employee) {
		employee=employeeDAO.save(employee);
		return employee;
	}

	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeNotFound {
		return employeeDAO.findById(employeeId).orElseThrow(()->new EmployeeNotFound("employee details not found for the employeeID"+employeeId));
		 
	}

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return employeeDAO.findAll();
	}

	@Override
	public boolean removeEmployeeDetails(int employeeId) throws EmployeeNotFound {
		employeeDAO.deleteById(employeeId);
		return true;
	}


	}


